-- NEST IB SUPPORT v1.0 · Ejecutar UNA VEZ tras las tablas decks, flashcards y profiles existentes.
-- No borra las tarjetas existentes. Revisa primero el README y haz respaldo.
BEGIN;

ALTER TABLE public.decks ADD COLUMN IF NOT EXISTS revision integer NOT NULL DEFAULT 0;
ALTER TABLE public.decks ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE TABLE IF NOT EXISTS public.moderators (
 user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.moderators ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.moderators FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.is_nest_moderator()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
 SELECT EXISTS (SELECT 1 FROM public.moderators WHERE user_id = (SELECT auth.uid()));
$$;
REVOKE ALL ON FUNCTION public.is_nest_moderator() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_nest_moderator() TO anon, authenticated;

CREATE TABLE IF NOT EXISTS public.collections (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 title text NOT NULL CHECK (length(trim(title)) BETWEEN 3 AND 120),
 description text NOT NULL CHECK (length(trim(description)) BETWEEN 10 AND 1500),
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','published','rejected')),
 review_note text,
 created_at timestamptz NOT NULL DEFAULT now(),
 reviewed_at timestamptz
);
CREATE INDEX IF NOT EXISTS collections_owner_idx ON public.collections(owner_id);
CREATE INDEX IF NOT EXISTS collections_status_idx ON public.collections(status,created_at DESC);
ALTER TABLE public.collections ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.collection_decks (
 collection_id uuid NOT NULL REFERENCES public.collections(id) ON DELETE CASCADE,
 deck_id uuid NOT NULL REFERENCES public.decks(id) ON DELETE RESTRICT,
 PRIMARY KEY (collection_id,deck_id)
);
CREATE INDEX IF NOT EXISTS collection_decks_deck_idx ON public.collection_decks(deck_id);
ALTER TABLE public.collection_decks ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.saved_collections (
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 collection_id uuid NOT NULL REFERENCES public.collections(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id,collection_id)
);
ALTER TABLE public.saved_collections ENABLE ROW LEVEL SECURITY;

-- Restituimos permisos de lectura: TODAS las escrituras sensibles pasan por funciones validadas.
REVOKE ALL ON public.decks, public.flashcards, public.collections,
 public.collection_decks, public.saved_collections FROM anon, authenticated;
GRANT SELECT ON public.decks, public.flashcards, public.collections,
 public.collection_decks TO anon, authenticated;
GRANT SELECT, INSERT, DELETE ON public.saved_collections TO authenticated;

-- Reemplazar las políticas de la versión inicial, no sumarlas mediante OR.
DROP POLICY IF EXISTS "Leer conjuntos propios" ON public.decks;
DROP POLICY IF EXISTS "Crear conjuntos propios" ON public.decks;
DROP POLICY IF EXISTS "Editar conjuntos propios" ON public.decks;
DROP POLICY IF EXISTS "Eliminar conjuntos propios" ON public.decks;
DROP POLICY IF EXISTS "Leer tarjetas propias" ON public.flashcards;
DROP POLICY IF EXISTS "Crear tarjetas propias" ON public.flashcards;
DROP POLICY IF EXISTS "Editar tarjetas propias" ON public.flashcards;
DROP POLICY IF EXISTS "Eliminar tarjetas propias" ON public.flashcards;

CREATE POLICY nest_decks_read ON public.decks FOR SELECT TO anon, authenticated USING (
 owner_id = (SELECT auth.uid()) OR (SELECT public.is_nest_moderator()) OR
 EXISTS (SELECT 1 FROM public.collection_decks cd
         JOIN public.collections c ON c.id=cd.collection_id
         WHERE cd.deck_id=decks.id AND c.status='published')
);
CREATE POLICY nest_cards_read ON public.flashcards FOR SELECT TO anon, authenticated USING (
 EXISTS (SELECT 1 FROM public.decks d WHERE d.id=flashcards.deck_id)
);
CREATE POLICY nest_collections_read ON public.collections FOR SELECT TO anon, authenticated USING (
 status='published' OR owner_id=(SELECT auth.uid()) OR (SELECT public.is_nest_moderator())
);
CREATE POLICY nest_collection_decks_read ON public.collection_decks FOR SELECT TO anon, authenticated USING (
 EXISTS (SELECT 1 FROM public.collections c WHERE c.id=collection_id)
);
CREATE POLICY nest_saved_read ON public.saved_collections FOR SELECT TO authenticated USING (user_id=(SELECT auth.uid()));
CREATE POLICY nest_saved_insert ON public.saved_collections FOR INSERT TO authenticated
 WITH CHECK (user_id=(SELECT auth.uid()) AND EXISTS (
 SELECT 1 FROM public.collections c WHERE c.id=collection_id AND c.status='published'));
CREATE POLICY nest_saved_delete ON public.saved_collections FOR DELETE TO authenticated USING (user_id=(SELECT auth.uid()));

-- Publicación de seudónimos sin publicar el email (profiles solo tiene id, nickname, created_at).
DROP POLICY IF EXISTS nest_public_author_alias ON public.profiles;
CREATE POLICY nest_public_author_alias ON public.profiles FOR SELECT TO anon, authenticated USING (
 EXISTS (SELECT 1 FROM public.collections c WHERE c.owner_id=profiles.id AND c.status='published')
);
GRANT SELECT (id,nickname) ON public.profiles TO anon;
-- Los roles authenticated conservan la lectura de su propio perfil previamente concedida.

-- Guardado sincronizado en una sola transacción y con control de versiones.
CREATE OR REPLACE FUNCTION public.nest_save_deck(
 p_id uuid, p_expected integer, p_title text, p_subject text,
 p_level text, p_description text, p_cards jsonb
) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_owner uuid:=auth.uid(); v_rev integer; v_row jsonb; v_new integer;
BEGIN
 IF v_owner IS NULL THEN RAISE EXCEPTION 'Debes iniciar sesión'; END IF;
 IF p_id IS NULL OR p_expected IS NULL OR p_expected<0
  OR length(trim(coalesce(p_title,''))) NOT BETWEEN 1 AND 120
  OR length(coalesce(p_description,''))>1500 OR length(coalesce(p_subject,''))>80
  OR length(coalesce(p_level,''))>40 OR jsonb_typeof(p_cards) IS DISTINCT FROM 'array'
  OR jsonb_array_length(p_cards)>1000 THEN RAISE EXCEPTION 'Datos del conjunto no válidos'; END IF;
 FOR v_row IN SELECT value FROM jsonb_array_elements(p_cards) LOOP
  IF jsonb_typeof(v_row) <> 'object' OR
     length(trim(coalesce(v_row->>'front',''))) NOT BETWEEN 1 AND 2000 OR
     length(trim(coalesce(v_row->>'back',''))) NOT BETWEEN 1 AND 6000 OR
     length(coalesce(v_row->>'extra',''))>6000
  THEN RAISE EXCEPTION 'Tarjeta inválida o demasiado extensa'; END IF;
 END LOOP;
 SELECT revision INTO v_rev FROM public.decks WHERE id=p_id AND owner_id=v_owner FOR UPDATE;
 IF NOT FOUND THEN
  IF EXISTS (SELECT 1 FROM public.decks WHERE id=p_id) THEN RAISE EXCEPTION 'Conjunto ajeno'; END IF;
  IF p_expected<>0 THEN RAISE EXCEPTION 'Conflicto de sincronización: recarga tu biblioteca'; END IF;
  INSERT INTO public.decks(id,owner_id,title,subject,level,description,revision)
  VALUES(p_id,v_owner,trim(p_title),left(coalesce(p_subject,''),80),left(coalesce(p_level,''),40),p_description,1);
  v_new:=1;
 ELSE
  IF v_rev<>p_expected THEN RAISE EXCEPTION 'Conflicto de sincronización: otra versión fue guardada'; END IF;
  IF EXISTS (SELECT 1 FROM public.collection_decks cd JOIN public.collections c ON c.id=cd.collection_id
             WHERE cd.deck_id=p_id AND c.status IN ('pending','published'))
  THEN RAISE EXCEPTION 'El conjunto está presentado o publicado. Duplica el deck para editarlo.'; END IF;
  UPDATE public.decks SET title=trim(p_title),subject=coalesce(p_subject,''),level=coalesce(p_level,''),
   description=coalesce(p_description,''),revision=revision+1,updated_at=now() WHERE id=p_id;
  v_new:=v_rev+1;
  DELETE FROM public.flashcards WHERE deck_id=p_id;
 END IF;
 INSERT INTO public.flashcards(deck_id,question,answer,extra_info)
 SELECT p_id,elem->>'front',elem->>'back',jsonb_build_object('text',coalesce(elem->>'extra',''))
 FROM jsonb_array_elements(p_cards) elem;
 RETURN v_new;
END;
$$;
REVOKE ALL ON FUNCTION public.nest_save_deck(uuid,integer,text,text,text,text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.nest_save_deck(uuid,integer,text,text,text,text,jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.nest_delete_deck(p_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Acceso denegado'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.decks WHERE id=p_id AND owner_id=auth.uid()) THEN RAISE EXCEPTION 'Conjunto no encontrado'; END IF;
 IF EXISTS (SELECT 1 FROM public.collection_decks WHERE deck_id=p_id) THEN
   RAISE EXCEPTION 'El conjunto forma parte de un paquete. No puede eliminarse desde aquí.';
 END IF;
 DELETE FROM public.decks WHERE id=p_id;
END; $$;
REVOKE ALL ON FUNCTION public.nest_delete_deck(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.nest_delete_deck(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.nest_submit_package(
 p_title text,p_description text,p_deck_ids uuid[]
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_id uuid; v_owner uuid:=auth.uid(); v_count int;
BEGIN
 IF v_owner IS NULL THEN RAISE EXCEPTION 'Inicia sesión'; END IF;
 IF length(trim(coalesce(p_title,''))) NOT BETWEEN 3 AND 120 OR
    length(trim(coalesce(p_description,''))) NOT BETWEEN 10 AND 1500 OR
    coalesce(array_length(p_deck_ids,1),0) NOT BETWEEN 1 AND 30
 THEN RAISE EXCEPTION 'Completa título, descripción y entre 1 y 30 decks'; END IF;
 IF (SELECT count(*) FROM public.collections WHERE owner_id=v_owner AND status='pending')>=5
 THEN RAISE EXCEPTION 'Ya tienes cinco paquetes en revisión'; END IF;
 SELECT count(DISTINCT d.id) INTO v_count FROM public.decks d
 WHERE d.id=ANY(p_deck_ids) AND d.owner_id=v_owner
 AND EXISTS(SELECT 1 FROM public.flashcards f WHERE f.deck_id=d.id);
 IF v_count<>array_length(p_deck_ids,1) THEN RAISE EXCEPTION 'Todos los decks deben ser tuyos y tener tarjetas, sin repetidos'; END IF;
 INSERT INTO public.collections(owner_id,title,description,status)
 VALUES(v_owner,trim(p_title),trim(p_description),'pending') RETURNING id INTO v_id;
 INSERT INTO public.collection_decks(collection_id,deck_id)
 SELECT v_id, unnest(p_deck_ids);
 RETURN v_id;
END; $$;
REVOKE ALL ON FUNCTION public.nest_submit_package(text,text,uuid[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.nest_submit_package(text,text,uuid[]) TO authenticated;

CREATE OR REPLACE FUNCTION public.nest_review_package(p_id uuid,p_approve boolean,p_note text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.is_nest_moderator() THEN RAISE EXCEPTION 'Solo moderadores'; END IF;
 IF coalesce(length(p_note),0)>1000 THEN RAISE EXCEPTION 'Nota demasiado larga'; END IF;
 IF NOT p_approve AND length(trim(coalesce(p_note,'')))<5 THEN RAISE EXCEPTION 'Explica el motivo del rechazo'; END IF;
 UPDATE public.collections SET status=CASE WHEN p_approve THEN 'published' ELSE 'rejected' END,
 review_note=coalesce(p_note,''),reviewed_at=now()
 WHERE id=p_id AND status='pending';
 IF NOT FOUND THEN RAISE EXCEPTION 'Paquete no encontrado o ya revisado'; END IF;
END; $$;
REVOKE ALL ON FUNCTION public.nest_review_package(uuid,boolean,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.nest_review_package(uuid,boolean,text) TO authenticated;
COMMIT;
