# NEST IB SUPPORT — Flashcards colaborativas v1.0

## Qué incluye

- Conjuntos de tarjetas: creación manual, CSV de NotebookLM y Excel (primera hoja).
- Modo estudio, CSV e impresión como tabla A4.
- Guardado local de visitantes; sincronización con Supabase al iniciar sesión, al editar y al recuperar el foco (no es edición simultánea en tiempo real).
- Paquetes comunitarios con título, descripción y selección de 1 a 30 decks.
- Solicitudes de revisión y panel de moderadores; biblioteca pública de paquetes aprobados.
- Favoritos de paquetes y copias editables de decks públicos.
- JSON descargable para respaldos externos, por ejemplo Google Drive.

## Antes de instalar

1. **Guarda una copia de toda tu web actual**. No borres `login.html`, `auth.js`, `index.html`, `style.css`, `script.js`.
2. Asegúrate de que ya existen `public.decks`, `public.flashcards` y `public.profiles`, creadas en las fases anteriores.
3. En Supabase > SQL Editor > New query, ejecuta `01_SUPABASE_MIGRACION.sql` **solo una vez**. No mezcles este script con SQL anteriores. No ejecutes scripts destructivos de cero.
4. En Supabase > Table Editor deben aparecer `collections`, `collection_decks`, `saved_collections`, `moderators` y las tablas anteriores.
5. Si quieres moderar, en Supabase > Authentication > Users copia **tu propio UUID de usuario**. En SQL Editor ejecuta:

   ```sql
   INSERT INTO public.moderators(user_id)
   VALUES ('PEGA_AQUI_TU_UUID_DE_USUARIO');
   ```

   Hazlo solamente como administrador desde Supabase. No añadas la clave secret/service_role al navegador.

## Archivos

Copia estos cuatro archivos en la misma carpeta que `index.html`:

- `flashcards.html`
- `flashcards.css`
- `flashcards.js`
- `flashcards-config.js`

En `flashcards-config.js`, reemplaza el valor `publishableKey` por la **misma clave pública** que funciona en `auth.js`. La URL debe corresponder a ese proyecto. No copies una clave secreta.

No cargues `flashcards-app.js` ni `flashcards-cloud.js` en la nueva página; puedes conservar los archivos anteriores en tu copia de seguridad.

En `index.html`, confirma que Flashcards utiliza `href="flashcards.html"` en lugar de un botón `data-herramienta` con alerta de «próximamente».

## Pruebas en Live Server

1. Abre `login.html` e inicia sesión.
2. Abre `flashcards.html` con el **mismo host y puerto** (por ejemplo, `127.0.0.1:5500`).
3. Crea un deck y añade tarjetas. Pulsa «Sincronizar»; verifica filas nuevas en `decks` y `flashcards`.
4. Abre en otro navegador con la misma cuenta, carga la página y comprueba los decks.
5. Enviar paquete a revisión: completa título, descripción y selecciona decks sincronizados.
6. Como moderador, entra en la pestaña Moderación y aprueba o rechaza. Comprueba la biblioteca pública con una cuenta distinta o como visitante.
7. Guarda el paquete, quítalo de guardados y copia uno de sus decks. Comprueba que los originales no cambian.
8. Importa `flashcards.csv` de NotebookLM (sin encabezados) y tu Excel (con encabezados); revisa el cuadro imprimible.
9. Descarga «Respaldo JSON» y súbelo manualmente a una carpeta de Google Drive.
10. Solo tras las pruebas locales, sube los 4 archivos a GitHub Pages y comprueba el despliegue en GitHub Actions.

## Google Drive: configuración sencilla y gratuita

1. En Google Drive crea una carpeta `NEST IB SUPPORT - Respaldos`.
2. En Flashcards, pulsa `Descargar respaldo JSON (Google Drive)`.
3. Abre Google Drive, entra en esa carpeta y usa `Nuevo > Subir archivo`.
4. Conserva respaldos fechados, por ejemplo semanales.
5. Para recuperar, descarga el JSON de Drive y pulsa `Importar respaldo JSON` dentro de Flashcards.

**Drive no está conectado automáticamente** y no almacena los datos de todos los estudiantes. El respaldo JSON contiene únicamente los decks accesibles en el navegador/cuenta desde el que exportas. No incluye contraseñas, ni es un respaldo completo de la base de datos Supabase. Para un respaldo administrativo integral debes usar los mecanismos de exportación/backup de PostgreSQL de Supabase y guardarlo de forma segura. No publiques respaldos en un enlace abierto.

## Seguridad y límites de esta primera versión comunitaria

- RLS y funciones SQL validan propiedad, edición, revisión, acceso público y conflictos de versión.
- Los decks en paquetes pendientes o aprobados quedan **inmutables**. Duplica uno para editarlo. Las modificaciones se reenvían como paquete nuevo.
- Los cambios en decks editables se guardan al editar cuando hay sesión y conexión; al volver a cargar o enfocar la pestaña se recupera la versión de Supabase. Si hay conflicto, se conserva la versión local y se muestra un error. **No es edición multiusuario simultánea**.
- No hay borrado masivo ni sustitución silenciosa de decks locales. Una importación JSON agrega copias.
- El panel de moderación incorpora una vista de hasta 20 tarjetas por deck. Para una revisión exhaustiva, abre Supabase Table Editor y verifica las restantes antes de aprobar.
- No hemos incluido subida de PDFs ni archivos arbitrarios; evita compartir material protegido, evaluaciones internas ajenas y datos personales.
- Los estudiantes que reutilicen material deben respetar atribución y derechos de autor; esta versión todavía no registra licencias por tarjeta.
- Las publicaciones públicas no se editan directamente. La API permite una cola máxima de 5 paquetes pendientes y 30 decks por paquete.
- El Excel depende de la carga de SheetJS desde CDN (requiere red al importarlo); CSV e impresión funcionan localmente.
- El almacenamiento local de visitantes está asociado a su navegador; no equivale a una cuenta en la nube.

## Si aparece un error

- `Invalid API key`: revisa clave publicable y URL en `flashcards-config.js`.
- `Could not find the function`: ejecuta la migración SQL en el proyecto correcto y recarga la página.
- `Conflicto de sincronización`: hay una versión más nueva en la nube; conserva tu archivo JSON, y duplica o importa la versión deseada antes de sobrescribir nada.
- `permission denied` / `row-level security`: revisa que has iniciado sesión y que las funciones SQL se crearon correctamente.
- `Cannot find flashcards.js`: comprueba nombre, mayúsculas, ruta y que el archivo no pese 0 KB.

## Próximas mejoras antes de un lanzamiento público grande

Pruebas de permisos con dos usuarios, revisión de políticas RLS, detección de contenido inadecuado, límites anti-spam, interfaz de revisión de todas las tarjetas, auditoría de moderadores, versiones editables de publicaciones, accesibilidad y política de privacidad.
