// Copia desde tu archivo auth.js, usando SOLO la URL y la clave publicable.
window.NEST_CONFIG = {
  url: 'https://kblkchtphbwlorvdkwot.supabase.co',
  publishableKey: 'sb_publishable_dgtesFWFl04VWc9D7VLeWQ_jyD2Syly'
};
